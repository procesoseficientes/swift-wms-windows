﻿Public Partial Class SONDA_GetGeoPoints_ByRoute
    Inherits System.Web.UI.Page

End Class